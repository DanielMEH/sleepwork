class Skynet{
  //aca se definen los atributos del terminator(objeto de la clase)
  constructor(color, altura, peso, sigiloso, agresivo){
    this.color = color;
    this.altura = altura;
    this.peso = peso;
    this.sigiloso = sigiloso;
    this.agresivo = agresivo;
  }

  //aca definimos las acciones del terminator(se llaman métodos del objeto)
  correr(){
    console.log("Terminator corriendo");
  }

  disparar(){
    console.log("Terminator disparando");
  }

  detenerse(){
    console.log("Terminator detenido");
  }

}
//aca terminatorT800 es una instancia de la clase Skynet
//crear un objeto es instanciar
let terminatorT800 = new Skynet("Azul", 2, 100, true, false);
terminatorT800.disparar();
terminatorT800.correr();
terminatorT800.detenerse();
console.log(terminatorT800.color);
console.log("------------------------------------");
let terminatorT500 = new Skynet("Metalico", 1.78, 90, false, true);
terminatorT800.disparar();
terminatorT800.correr();
terminatorT800.detenerse();
console.log(terminatorT500.agresivo);
console.log(terminatorT500.sigiloso);